﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FinalExam
{
    public class Lawyer : Employee, IListCases //Inherits from Employee + implements IListCases
    {
        public Lawyer(int id, string password, string firstName, string lastName, DateTime dob, ESeniority seniority, ECaseType expertiseDomain, DateTime joinedOn)
            : base(id, password, firstName, lastName, joinedOn) //Inhertited from Employee Class

        //Fields are new and specific to Lawyer Class
        {
            DoB = dob;
            Seniority = seniority;
            ExpertiseDomain = expertiseDomain;
        }


        // Empty Constructor
        public Lawyer()
        {
        }


        private DateTime DoB

        {
            get;
            set;

        }

        private ESeniority Seniority { get; set; }

        private ECaseType ExpertiseDomain { get; set; }





        public Case AddNewCase(List<Employee> employeeList, List<Client> clientList) // Takes list of Employees + Clients 
        {
          

            Case newCase = new Case(); //starts off by creating an emptynewCase object and then it fills up with lawyer ID, customer Id, casetype, Charge..


            Console.WriteLine("*** Add case ***");

            // ValidLawyerID
            bool validLawyerId = false;
            while (validLawyerId == false)
            {


                Console.WriteLine("\n\nEnter LawyerID: ");
                var LawyerInput = Console.ReadLine();
                newCase.LawyerId = ExceptionHandling.HandleIntException(LawyerInput);


                foreach (Employee e in employeeList) //polymorphism - e in this case is a Lawyer 
                {
                    if (newCase.LawyerId == e.Id && e.GetType().Name == "Lawyer")
                    {
                        validLawyerId = true;
                    }
                }

                if (validLawyerId == false)
                {
                    Console.WriteLine("\nError - LawyerID not found. Enter LawyerID again.");
                }
            }



            // ValidCustomerID / Create newClient
            bool validCustomerId = false;
            while (validCustomerId == false)
            {
                Console.WriteLine("\nEnter ClientID: ");
                var ClientInput = Console.ReadLine();
                newCase.CustomerId = ExceptionHandling.HandleIntException(ClientInput);

                foreach (Client c in clientList)

                {
                    if (newCase.CustomerId == c.ClientId)

                    {
                        validCustomerId = true;
                    }
                }

                if (validCustomerId == false)

                {
                    Console.WriteLine("\nError - ClientID not found. Enter ClientID again.");
                }
            }



            // CaseTypeIdentification

            Console.WriteLine("\nEnter case type. Enter 1: Corporate/ 2: Family/ 3: Criminal");

            bool caseTypeIdentification = false;
            while (caseTypeIdentification == false)

            {
                string caseType = Console.ReadLine();

                switch (caseType)

                {                    
                    case "1":
                        newCase.CaseType = ECaseType.Corporate;
                        caseTypeIdentification = true;
                        break;

                    case "2":
                        newCase.CaseType = ECaseType.Family;
                        caseTypeIdentification = true;
                        break;

                    case "3":
                        newCase.CaseType = ECaseType.Criminal;
                        caseTypeIdentification = true;
                        break;

                    default:

                        Console.WriteLine("\nError - CaseType not found. Enter 1/2/3 again.");
                        break;
                }
            }



            // StartDate
            Console.WriteLine("\nEnter Start Date (dd-MM-yyyy): ");
            var DateInput = Console.ReadLine();
            newCase.StartDate = ExceptionHandling.HandleShortDateTimeException(DateInput);//Put the entered StartDate in and validate it. 

            bool validCharges = false;
            while (validCharges == false)

            {
                Console.WriteLine("\nEnter total charges: ");
                var ChargesInput = Console.ReadLine();
                newCase.TotalCharges = ExceptionHandling.HandleIntException(ChargesInput);

                if (newCase.TotalCharges > 0)

                {
                    validCharges = true;
                }

                else

                {
                    Console.WriteLine("\nError - Charges must be bigger than 0. Enter again.");
                }
            }

            Console.WriteLine("\nEnter case description: ");
            newCase.CaseDescription = Console.ReadLine();

            Console.WriteLine("\nEnter notes: ");
            newCase.Notes = Console.ReadLine();


            // Overview of NewCase
            Console.WriteLine("Case successfully added. Case details:\n" +
                " " + newCase + " " +
                "\n Hit enter.");
            Console.ReadLine();
           

            return newCase;

        }




        // Function looks through each of the Cases and writes the case down
  
        public void ListCases(List<Case> caseList) 

        {
           
            Console.WriteLine("*** Cases ***\n");
            foreach (Case c in caseList)

            {
                Console.WriteLine(c);
            }

            Console.WriteLine("Hit enter.");
            Console.ReadLine();
           
        }
    }
}
