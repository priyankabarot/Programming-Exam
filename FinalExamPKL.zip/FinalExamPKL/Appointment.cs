﻿using System;
using System.Collections.Generic;
using System.Text;


namespace FinalExam

{
    public class Appointment

        // Properties 
    {
        public int id { get; set; } 

        public int clientId { get; set; }

        public int LawyerId { get; set; }

        public DateTime DateTime { get; set; }

        public MeetingRoom MeetingRoom { get; set; } 


        // ToString method is overridden and prints all the details
        public override string ToString()
        {
            return "AppointmentID: " + id +
                "\nClientID: " + clientId +
                "\nLawyerID: " + LawyerId +
                "\nDate: " + DateTime.ToLongDateString() + " , " + DateTime.Hour + ":00" +
                "\n" + MeetingRoom +
                "\n";
        }
    }
}