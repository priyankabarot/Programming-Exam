﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FinalExam
{

    // Following methods ensure correct user input - security sytems 


    public class ExceptionHandling
    {
        // Method is called when User should enter an integer

        public static int HandleIntException(string enteredInt)

        {


            string inputInt = enteredInt;
            int convertedInt = -1;
            while (convertedInt == -1)
            {
                try
                {
                    convertedInt = Convert.ToInt32(inputInt);
                }

                catch

                {
                    Console.WriteLine("\nEnter an integer.");
                    inputInt = Console.ReadLine();
                }

            }


            return convertedInt;
        }

        // Method is called when User should enter a string

        public static string StringValidation(string enteredString)

        {
            string inputString = enteredString;
            string checkedString = "";
            int counter = 0;
            bool onlyStr = false;


            while (onlyStr == false)

            {
                foreach (char c in inputString)

                {
                    if (!char.IsLetter(c))

                    {
                        counter++;
                    }
                }


                if (counter > 0)

                {
                    Console.WriteLine("\nEnter text here (No numbers, spaces or special characters)");
                    counter = 0;
                    inputString = Console.ReadLine();
                }

                else

                {
                    onlyStr = true;
                    checkedString = inputString;
                }
            }


           return checkedString;

        }

        // Method is called when User should enter DateTime

        public static DateTime HandleShortDateTimeException(string enteredDateTime)
        {
            string inputDateTime = enteredDateTime;
            DateTime dateTime = DateTime.ParseExact("01-01-1900", "dd-MM-yyyy", null);

            while (dateTime == DateTime.ParseExact("01-01-1900", "dd-MM-yyyy", null))

            {
                try

                {
                    dateTime = DateTime.ParseExact(inputDateTime.Trim(), "dd-MM-yyyy", null);
                }

                catch

                {
                    Console.WriteLine("\nError - Date was entered in wrong format. Enter again.");
                    inputDateTime = Console.ReadLine();
                }
            }

            return dateTime;
        }

        // Method is called when User should enter Date + Time

        public static DateTime HandleLongDateTimeException(string enteredDateTime)

        {

            string inputDateTime = enteredDateTime;
            DateTime dateTime = DateTime.ParseExact("01-01-1900,01", "dd-MM-yyyy,HH", null);

            while (dateTime == DateTime.ParseExact("01-01-1900,01", "dd-MM-yyyy,HH", null))

            {
                try

                {
                    dateTime = DateTime.ParseExact(inputDateTime.Trim(), "dd-MM-yyyy,HH", null);
                }

                catch

                {
                    Console.WriteLine("\nError - Date and time were entered in wrong format. Enter again.");
                    inputDateTime = Console.ReadLine();
                }
            }


            return dateTime;
        }
    }
}
