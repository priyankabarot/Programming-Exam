﻿using System;
using System.Collections.Generic;
using System.Text;


namespace FinalExam

{
    public class Processor

    {


        public void Process()
        {
            // Instantiation
            // Those 5 functions are loading the data in before we can start on the login (the data we put in hard coded in Instantiate class)

            List<Employee> EmployeeList = Instantiate.InstantiateEmployees();
            List<MeetingRoom> MeetingRoomList = Instantiate.InstantiateMeetingRooms();
            List<Appointment> AppointmentList = Instantiate.InstantiateAppointments(MeetingRoomList);
            List<Client> ClientList = Instantiate.InstantiateClients();
            List<Case> CaseList = Instantiate.InstantiateCases(); 




            // Showcases the Login-process
            int employeeType = Login(EmployeeList);

            // Menu for Employee type and create User input
            // Data base is passed into ListCases


            // as long as no correct input was given the 
            bool quitProgram = false;
            while (quitProgram == false)

            {
                switch (employeeType)

                {


                    // if lawyer was chosen
                    case 1:
                        Lawyer lawyer = new Lawyer(); //Instantiate Lawyer Class
                        int menuLawyer = LawyerMenu(); 
                        
                        switch (menuLawyer)

                        {
                            case 1:
                                lawyer.ListCases(CaseList); //Accessing the function from the Lawyer Class
                                break;

                            case 2:

            
                                var newCase = lawyer.AddNewCase(EmployeeList, ClientList); 
                                CaseList.Add(newCase); //A List always needs .Add
                                break;

                            case 3:
                                lawyer.ListAppointments(AppointmentList); //Accessing the function from the Lawyer Class
                                break;

                            case 4:
                                
                                Console.WriteLine("Application ended" +
                                    "\nGoodbye ;-)!");
                                Console.ReadLine();
                                quitProgram = true;
                                break;
                        }

                        break;


                    // if admin was chosen
                    case 2:
                        Administrator administrator = new Administrator(); //Instantiate Administrator Class
                        int menuAdmin = AdministratorMenu();
                        switch (menuAdmin)
                        {
                            case 1:
                                administrator.ListCases(CaseList); //Accessing the function from the administrator class
                                break;

                            case 2:
                                administrator.ListAppointments(AppointmentList); //Accessing the function from the administrator class
                                break;

                            case 3:
                               
                                Console.WriteLine("Application ended" +
                                    "\nGoodbye ;-)!");
                                Console.ReadLine();
                                quitProgram = true;
                                break;
                        }

                        break;


                    // if receptionist was chosen
                    case 3:

                        Receptionist receptionist = new Receptionist(); //Instantiate Receptionist Class
                        int menuReceptionist = ReceptionistMenu();

                        switch (menuReceptionist)

                        {
                            case 1:
                                ClientList.Add(receptionist.AddNewClient(ClientList)); //accessing our List data
                                break;

                            case 2:
                                AppointmentList.Add(receptionist.AddNewAppointment(ClientList, AppointmentList, EmployeeList, MeetingRoomList)); //accessing our List data
                                break;

                            case 3:
                                receptionist.ListAppointments(AppointmentList); //Accessing the function from the receptionist class
                                break;

                            case 4:
                                receptionist.ListClients(ClientList); //Accessing the function from the receptionist class
                                break;

                            case 5:
                                
                                Console.WriteLine ("Application ended" +
                                    "\nGoodbye ;-)!");
                                Console.ReadLine();
                                quitProgram = true;
                                break;
                        }

                        break;
                }
            }
        }


        // This is where the program starts for the User
        private int Login(List<Employee> employees)

        {
            List<Employee> eList = employees;
            int trueEmployeeType = 0;
            bool validCombination = false;

            // Will be in the loop until login successfully turns true
            //Repeat login process until the credentials are true
            bool loginSuccessful = false;
            while (loginSuccessful == false)
            {
                string enteredFirstname, enteredPassword;
                string employeeType = string.Empty;

                Console.WriteLine("************* Hello LegalX Employee! ************* " +
                    "\nPlease choose option 1/2/3/4 to select your employment type and hit enter!" +
                    "\n1. Lawyer" +
                    "\n2. Administrator" +
                    "\n3. Receptionist ");

                bool validEmployeeType = false;
                while (validEmployeeType == false)
                {

                    // ValidEmployeeType input
                    employeeType = Console.ReadLine();
                    trueEmployeeType = ExceptionHandling.HandleIntException(employeeType);

                  
                    employeeType = Convert.ToString(trueEmployeeType);

                    // Convert User input (1-4) to string (eg. Lawyer)
                    if (employeeType == "1")

                    {
                        employeeType = "Lawyer";
                        validEmployeeType = true;

                    }

                    else if (employeeType == "2")

                    {
                        employeeType = "Administrator";
                        validEmployeeType = true;
                    }

                    else if (employeeType == "3")

                    {
                        employeeType = "Receptionist";
                        validEmployeeType = true;
                    }

                    else

                    {
                        Console.WriteLine("\nEnter 1/2/3");
                    }
                }


                // Validate Firstname + Password
                Console.WriteLine("\nEnter firstname to access the LegalX system: ");
                enteredFirstname = Console.ReadLine();

                Console.WriteLine("\nEnter password: ");
                enteredPassword = Console.ReadLine();

                foreach (Employee X in eList)

                {
                    
                    // Did you enter real firstname and password?
                    if (enteredFirstname == X.FirstName && enteredPassword == X.Password)
                    {

                        // See if employeeType exists

                        if (X.GetType().Name.ToString() == employeeType && X.FirstName == enteredFirstname)
                        {
                            loginSuccessful = true; 
                        }

                        else
                        {
                            // Error message: not matching Role

                            Console.WriteLine("\nError - Credentials and role not found. Hit enter again.");

                            // When credentials are wrong validcombination is set to true

                            validCombination = true;
                            Console.ReadLine();
                          
                        }
                    }
                }

                if (loginSuccessful == false && validCombination == false)
                {
                    Console.WriteLine("\nError - Credentials not found. Enter again.");
                    Console.ReadLine();
                   
                }
            }

           
            return trueEmployeeType;
        }




        // LawyerMenu(options)
        private int LawyerMenu()

        {
            Console.WriteLine("*** Menu ***" +
                    "\n\nEnter 1/2/3/4" +
                    "\n\n1. List all cases" +
                    "\n2. Add new case" +
                    "\n3. List all appointments" +
                    "\n4. Exit program");

            int choice = 0;
            bool validChoice = false;
            while (validChoice == false)

            {
                choice = ExceptionHandling.HandleIntException(Console.ReadLine());


                if (choice >= 1 && choice <= 4)

                {
                    validChoice = true;
                }

                else

                {
                    Console.WriteLine("\nChoose 1 / 2 / 3 / 4 and then hit enter.");
                }
            }

            return choice;
        }



        // AdministratorMenu(options)
        private int AdministratorMenu()
        {
            Console.WriteLine("*** Menu ***" +
                    "\n\nChoose 1/2/3 and hit enter." +
                    "\n1. List all cases" +
                    "\n2. List all appointments" +
                    "\n3. Exit program");

            int choice = 0;
            bool validChoice = false;
            while (validChoice == false)
            {
                choice = ExceptionHandling.HandleIntException(Console.ReadLine());

                if (choice >= 1 && choice <= 3)
                {
                    validChoice = true;
                }
                else
                {
                    Console.WriteLine("\nSelect the number 1/2/3 and hit enter.");
                }
            }

            return choice;
        }

        // ReceptionistMenu(options)
        private int ReceptionistMenu()

        {
            Console.WriteLine("*** Menu ***" +
                    "\n\nChoose 1/2/3/4/5 and hit enter." +
                    "\n\n1. Register a new client" +
                    "\n2. Add a new appointment" +
                    "\n3. List all appointments" +
                    "\n4. List all clients" +
                    "\n5. Exit program");


            int choice = 0;
            bool validChoice = false;

            do

            {
                choice = ExceptionHandling.HandleIntException(Console.ReadLine());

                if (choice >= 1 && choice <= 5)

                {
                    validChoice = true;
                }

                else
                {
                    Console.WriteLine("\nSelect either 1/2/3/4/5 and hit enter.");
                }

            }

            while (validChoice == false);

            {
                Console.WriteLine();
            }


            return choice;
        }
    }
}
