﻿using System;
using System.Collections.Generic;
using System.Text;


namespace FinalExam

{

    public class Client


        // Define properties 
    {

        public int ClientId { get; set; }

        public string FirstName { get; set; }

        public string MiddleName { get; set; }

        public string LastName { get; set; }

        public DateTime DoB { get; set; }

        public ECaseType CaseType { get; set; }

        public string ShortDescription { get; set; }

        public string Street { get; set; }

        public int StreetNumber { get; set; }

        public int Zip { get; set; }

        public string City { get; set; }



        // Constructor
        public Client(int clientId, string firstName, string middleName, string lastName, DateTime dob, ECaseType caseType, string street, int streetNumber, int zip, string city)

        {
            ClientId = clientId;
            FirstName = firstName;
            MiddleName = middleName;
            LastName = lastName;
            DoB = dob;
            CaseType = caseType;
            Street = street;
            Zip = zip;
            City = city;
        }

        public Client()
        {
        }


        // ToString method is overridden and prints all the details

        public override string ToString()
        {
            return "ClientID: " + ClientId +
                "\nFirst Name: " + FirstName +
                "\nMiddle Name: " + MiddleName +
                "\nLast Name: " + LastName +
                "\nDoB: " + DoB.ToShortDateString() +
                "\nCase Type: " + CaseType +
                "\nShort description: " + ShortDescription+
                "\nStreet: " + Street +
                "\nZip Code: " + Zip +
                "\n";

        }
    }
}
