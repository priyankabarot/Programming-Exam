﻿using System;
using System.Collections.Generic;
using System.Text;


namespace FinalExam

{

    public class Case

    {

        public int CaseId { get; set; }

        public int CustomerId { get; set; }

        public ECaseType CaseType { get; set; }

        public DateTime StartDate { get; set; }

        public int TotalCharges { get; set; }

        public int LawyerId { get; set; }

        public string CaseDescription { get; set; } 

        public string Notes { get; set; } 


        public Case(int caseId, int customerId, ECaseType caseType, DateTime startDate, int totalCharges, int lawyerId, string caseDescription, string notes)

        {
            CaseId = caseId;
            CustomerId = customerId;
            CaseType = caseType;
            StartDate = startDate;
            TotalCharges = totalCharges;
            LawyerId = lawyerId;
            CaseDescription = caseDescription;
            Notes = notes;
        }


        public Case()

        {
        }


        // ToString method is overridden and prints all the details

        public override string ToString()

        {
            return "\nCaseID: " + CaseId +
                "\nCustomerID: " + CustomerId +
                "\nCase Type: " + CaseType +
                "\nStarting Date: " + StartDate.ToLongDateString() +
                "\nTotal Charges in USD$: " + TotalCharges +
                "\nLawyerID: " + LawyerId +
                "\nCase Description: " + CaseDescription +
                "\nNotes: " + Notes +
                "\n";
        }



    }
}