﻿using System;
using System.Collections.Generic;
using System.Text;


namespace FinalExam

{
    public class Receptionist : Employee
    {
        public Receptionist(int id, string password, string firstName,string lastName, DateTime joinedOn)
            : base(id, password, firstName, lastName, joinedOn)
        { }

        // Empty Constructor
        public Receptionist()
        {
        }

    
        public Client AddNewClient(List<Client> clientList)

        {
            

            Client newClient = new Client();
            Console.WriteLine("*** Add client ***");

            // Client's FirstName, MiddleName and LastName
            Console.WriteLine("\nEnter client's firstname: ");
            newClient.FirstName = Console.ReadLine();
            Console.WriteLine("\nEnter client's middlename: ");
            newClient.MiddleName = Console.ReadLine();
            Console.WriteLine("\nEnter client's lastname: ");
            newClient.LastName = Console.ReadLine();

            // Client's Date of Birth
            Console.WriteLine("\nEnter DoB (dd-mm-yyyy): ");
            newClient.DoB = ExceptionHandling.HandleShortDateTimeException(Console.ReadLine());

            // CaseType
            bool caseTypeIdentification = false;
            while (caseTypeIdentification == false)

            {
                Console.WriteLine("\nChoose a Case Type. Enter 1:Corporate/ 2:Family/ 3:Criminal");
                string caseType = Console.ReadLine();

                if (caseType == "1")

                {
                    newClient.CaseType = ECaseType.Corporate;
                    caseTypeIdentification = true;
                }

                else if (caseType == "2")

                {
                    newClient.CaseType = ECaseType.Family;
                    caseTypeIdentification = true;
                }

                else if (caseType == "3")

                {
                    newClient.CaseType = ECaseType.Criminal;
                    caseTypeIdentification = true;
                }

                else

                {
                    Console.WriteLine("\nYou must enter a valid case type. Choose between 1/2/3.");
                }
            }


            Console.WriteLine("\nEnter short description: ");
            newClient.ShortDescription = Console.ReadLine();

            
            // Client's Home Address
            Console.WriteLine("\nEnter street name and no.:");
            newClient.Street = Console.ReadLine();


            bool validZipCode = false;
            while (validZipCode == false)

            {
                Console.WriteLine("\nEnter four digit zip code:");
                newClient.Zip = ExceptionHandling.HandleIntException(Console.ReadLine());

                if (newClient.Zip.ToString().Length != 4)
                {
                    Console.WriteLine("\nError - invalid zip code! Enter only four digits.");
                }
                else

                {
                    validZipCode = true;
                }
            }

            // Create and add ClientID
          
            int counter = 0;

            foreach (Client c in clientList)
            {
                counter++;
            }

            newClient.ClientId = counter + 1;

            // Overview of succesfully added New client.
            
            Console.WriteLine("New client added sucessfully: \n" + newClient);
            Console.WriteLine("\n\nTo return hit enter.");
            Console.ReadLine();
            

            return newClient;
        }

        public Appointment AddNewAppointment(List<Client> clientList, List<Appointment> appointmentList, List<Employee> employeeList, List<MeetingRoom> meetingRoomList)

        {
            
            Appointment newAppointment = new Appointment();

            Console.WriteLine("*** Add appointment ***");

            // Add ClientID to Appointment.
            Console.WriteLine("\n\nChoose 1: new client/ 2: existing client");
            string choice = Console.ReadLine();
            bool clientAdded = false;

            while (clientAdded == false)
            {
                // If New Client then create and add their clientID to Appointment.
                if (choice == "1" || choice == "new")

                {
                    Client newClient = AddNewClient(clientList);
                    newAppointment.clientId = newClient.ClientId;
                    clientAdded = true;
                }

                // If NOT New Client, then let User write their ClientID and to an Appointment.
                else if (choice == "2" || choice == "existing")

                {
                    bool clientIdFound = false;
                    while (clientIdFound == false)

                    {
                        Console.WriteLine("\nEnter ClientID");
                        int enteredClientId = ExceptionHandling.HandleIntException(Console.ReadLine());
                        foreach (Client c in clientList)

                        {
                            if (c.ClientId == enteredClientId)
                            {
                                newAppointment.clientId = enteredClientId;
                                clientIdFound = true;
                                clientAdded = true;
                            }
                        }

                        if (clientIdFound == false)

                        {
                            Console.WriteLine("\nError - invalid ClientID! ");
                        }
                    }
                }

                else
                {
                    Console.WriteLine("\nEnter correct value");
                    choice = Console.ReadLine();
                }
            }

            // Add LawyerID for New Appointment
            bool lawyerFound = false;
            bool idMismatch = false;
            while (lawyerFound == false)
            {
                Console.WriteLine("\nEnter LaywerID for new appointment: ");
                int enteredId = ExceptionHandling.HandleIntException(Console.ReadLine());

                foreach (Employee e in employeeList)

                {
                    if (enteredId == e.Id)

                    {
                        if (Convert.ToString(e.GetType().Name) == "Lawyer")

                        {
                            newAppointment.LawyerId = enteredId;
                            lawyerFound = true;
                        }

                        else

                        {
                            Console.WriteLine("\nID: " + e.GetType().Name + ".");
                            idMismatch = true;
                        }
                    }
                }

                if (lawyerFound == false && idMismatch == false)

                {
                    Console.WriteLine("\nError - invalid ID!");
                }

            }

            // Assigning Meeting Room
            // Find a Meeting Room which has the allowed capacity and add to Appointment
            bool roomBookingSuccessful = false;
            while (roomBookingSuccessful == false)

            {
                Console.WriteLine("\nNumber of participants: ");
                int attendees = ExceptionHandling.HandleIntException(Console.ReadLine());
                if (attendees <= 0)

                {
                    Console.WriteLine("\nError - number must be bigger than 0! ");

                    //"Continue" will return User back to the start of the while-loop, instead of executing the rest of the code below.
                    continue; 
                }

                // If User typed attendees > 0, go through each Meeting Room and find the first one, which has the capacity. If found, add the Meeting Room and "break" out of the loop
                // If User did not break out of it, it will keep finding other rooms, which also have the capacity
         
                foreach (MeetingRoom r in meetingRoomList)
                {
                    if(r.Capacity >= attendees)
                    {
                        newAppointment.MeetingRoom = r;
                        roomBookingSuccessful = true;
                        //"breaks" out of the foreach loop and continues with the code below
                       
                        break;
                    }
                }

                if (roomBookingSuccessful == false)

                {
                    Console.WriteLine("\nMax capacity is 20. Hit Enter to try again.");
                }
            }


            // Date Time for Appointment
            // Since it is not needed to check if a Lawyer is already booked or not, the User can simply type data and add it to an Appointment
        
            Console.WriteLine("Enter date time for appointment (dd-MM-yyyy,HH)\n");
            DateTime proposedDateTime = ExceptionHandling.HandleLongDateTimeException(Console.ReadLine());
            newAppointment.DateTime = proposedDateTime;

            // Overview of New Appointment
           
            Console.WriteLine("You have successfully booked an appointment. The details are:\n" +
                newAppointment + " ");
            Console.ReadLine();
          

            return newAppointment;
        }



        // Function looks through list of clients and writes the client details down

        public void ListClients(List<Client> clients)
        {
            List<Client> clientList = clients;

           
            Console.WriteLine("*** List of all clients *** \n");
            foreach (Client c in clientList)
            {
                Console.WriteLine(c);
            }

            Console.WriteLine("\n\nHit enter to continue.");
            Console.ReadLine();
           
        }
    }
}