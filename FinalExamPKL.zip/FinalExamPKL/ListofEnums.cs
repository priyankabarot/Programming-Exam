﻿using System;
using System.Collections.Generic;
using System.Text;


namespace FinalExam

{

    // Following methods make system less error prone, only the respective integers can be selected and the respective values will be passed into it

    public enum ESeniority { Junior = 1, Senior = 2 } 

    public enum ECaseType {Corporate = 1, Family = 2, Criminal = 3 }

}

