﻿using System;

namespace FinalExam
{
    class Program //Entry point of the program
    {
        public static void Main(string[] args)
        {
            Processor p = new Processor();
            p.Process();
        }
    }
}
