﻿using System;
using System.Collections.Generic;
using System.Text;


namespace FinalExam

{

    public abstract class Employee //Abstract class 
    {

        // Constructor 
        public Employee(int id, string password, string firstName, string lastName, DateTime joinedOn)

        {

            Id = id;
            Password = password;
            FirstName = firstName;
            LastName = lastName;
            JoinedOn = joinedOn;

        }

        public Employee()
        {
        }

        // Properties Employees

        public int Id { get; set; }

        public string FirstName { get; set; }

        private string LastName { get; set; }

        private DateTime JoinedOn { get; set; }

        public string Password { get; set; }



        //Takes a list of appointments and prints - everyone who inherit from employee has ListAppointments

        public void ListAppointments(List<Appointment> appointments) 
        {

            
            Console.WriteLine("*** All appointments *** \n");
            foreach (Appointment a in appointments)

            {
                Console.WriteLine(a + "\n");
            }


            Console.WriteLine("\nHit enter to continue\n");
            Console.ReadLine();



        }
    }
}

