using System;
using System.Collections.Generic;


namespace FinalExam

{
    // A class for instantiating the database. It is static, since the class is only used once and will not be used afterwards. Also, it does not hold any state (it has no properties, it only has functions)

    public static class Instantiate
    {
        // Function which creates all of these employees
        // Polymorphism = we have a list of employees but we never create an employee at any time - only lawyers, administrator and receptionist.
        // Lawyers, administrator and receptionist are all employees - have all the functions from base class
        // You can have polymorphism without inhertitance, but not inheritance without polymorphism 

        public static List<Employee> InstantiateEmployees()

        {
            Lawyer lawyer1 = new Lawyer(97, "CBS", "Laila", "Sterheltou", DateTime.ParseExact("09-08-1997", "dd-MM-yyyy", null), ESeniority.Senior, ECaseType.Corporate, DateTime.ParseExact("05-11-2008", "dd-MM-yyyy", null));
            Lawyer lawyer2 = new Lawyer(95, "ILoveProgramming", "Priyanka", "Barot", DateTime.ParseExact("28-08-1995", "dd-MM-yyyy", null), ESeniority.Senior, ECaseType.Criminal, DateTime.ParseExact("09-02-2011", "dd-MM-yyyy", null));
            Lawyer lawyer3 = new Lawyer(98, "Orange", "Katharina", "Albrecht", DateTime.ParseExact("09-05-1998", "dd-MM-yyyy", null), ESeniority.Senior, ECaseType.Family, DateTime.ParseExact("23-08-2018", "dd-MM-yyyy", null));
            Lawyer lawyer4 = new Lawyer(86, "Grey", "Bruce", "Wayne", DateTime.ParseExact("11-05-1986", "dd-MM-yyyy", null), ESeniority.Senior, ECaseType.Corporate, DateTime.ParseExact("12-06-1995", "dd-MM-yyyy", null));
            Lawyer lawyer5 = new Lawyer(89, "Pink", "Miles", "Grayson", DateTime.ParseExact("14-03-1989", "dd-MM-yyyy", null), ESeniority.Senior, ECaseType.Criminal, DateTime.ParseExact("09-04-2000", "dd-MM-yyyy", null));
            Lawyer lawyer6 = new Lawyer(91, "Yellow", "Josh", "Admas", DateTime.ParseExact("09-08-1980", "dd-MM-yyyy", null), ESeniority.Senior, ECaseType.Family, DateTime.ParseExact("09-08-2003", "dd-MM-yyyy", null));
            Lawyer lawyer7 = new Lawyer(69, "White", "Peter", "Sandler", DateTime.ParseExact("09-08-1969", "dd-MM-yyyy", null), ESeniority.Senior, ECaseType.Corporate, DateTime.ParseExact("09-08-2000", "dd-MM-yyyy", null));
            Lawyer lawyer8 = new Lawyer(76, "Red", "Anne", "Frank", DateTime.ParseExact("09-08-1976", "dd-MM-yyyy", null), ESeniority.Junior, ECaseType.Corporate, DateTime.ParseExact("09-08-2018", "dd-MM-yyyy", null));
            Lawyer lawyer9 = new Lawyer(72, "Black", "Rosalita", "Gonzales", DateTime.ParseExact("09-08-1972", "dd-MM-yyyy", null), ESeniority.Junior, ECaseType.Corporate, DateTime.ParseExact("09-08-2016", "dd-MM-yyyy", null));
            Lawyer lawyer10 = new Lawyer(67, "Brown", "Rachel", "Green", DateTime.ParseExact("09-08-1967", "dd-MM-yyyy", null), ESeniority.Junior, ECaseType.Criminal, DateTime.ParseExact("09-08-2003", "dd-MM-yyyy", null));

          
         
            Administrator administrator1 = new Administrator(73, "Sun", "Kelly", "Clarksen", DateTime.Now, "Accountant");
            Administrator administrator2 = new Administrator(69, "Moon", "Robin", "Williams", DateTime.Now, "Intern");
            Administrator administrator3 = new Administrator(67, "Stars", "Michael", "Jackson", DateTime.Now, "Manager");

            Receptionist receptionist1 = new Receptionist(90, "Legal", "Sam", "Smith", DateTime.Now);


            List<Employee> employeeList = new List<Employee>

            {
                lawyer1, lawyer2, lawyer3, lawyer4, lawyer5, lawyer6, lawyer7, lawyer8, lawyer9, lawyer10,

                receptionist1,

                administrator1,administrator2, administrator3,
            };

            return employeeList;
        }

        // Instantiating MeetinRooms
        public static List<MeetingRoom> InstantiateMeetingRooms()

        {
            MeetingRoom meetingRoom1 = new MeetingRoom("Warriors", 20);
            MeetingRoom meetingRoom2 = new MeetingRoom("SOS", 15);
            MeetingRoom meetingRoom3 = new MeetingRoom("Cube", 10);
            MeetingRoom meetingRoom4 = new MeetingRoom("Cave", 8);

            List<MeetingRoom> meetingRooms = new List<MeetingRoom>

            {
                meetingRoom1,
                meetingRoom2,
                meetingRoom3,
                meetingRoom4,

            };

            return meetingRooms;
        }

        // Instantiate Appointments 
        // List of Meeting Rooms is passed into the functions > we can only have Appointments with Meeting Rooms
        // A Meeting Room can have different Appointments - we create one appointment for each room

        // Searching through what we need. Loop through all the Meeting Rooms and return one Meeting Room which fulfills condition
     
        public static List<Appointment> InstantiateAppointments(List<MeetingRoom> meetingRooms)

        {
            Appointment appointment1 = new Appointment() { clientId = 1, DateTime = DateTime.ParseExact("14-08-2021,12", "dd-MM-yyyy,HH", null), LawyerId = 1, id = 1, MeetingRoom = meetingRooms.Find(x => x.Name == "Warriors")};
            Appointment appointment2 = new Appointment() { clientId = 2, DateTime = DateTime.ParseExact("15-03-2021,12", "dd-MM-yyyy,HH", null), LawyerId = 2, id = 2, MeetingRoom = meetingRooms.Find(x => x.Name == "SOS")};
            Appointment appointment3 = new Appointment() { clientId = 3, DateTime = DateTime.ParseExact("14-08-2019,12", "dd-MM-yyyy,HH", null), LawyerId = 3, id = 3, MeetingRoom = meetingRooms.Find(x => x.Name == "Cube")};
            Appointment appointment4 = new Appointment() { clientId = 4, DateTime = DateTime.ParseExact("14-08-2019,12", "dd-MM-yyyy,HH", null), LawyerId = 4, id = 4, MeetingRoom = meetingRooms.Find(x => x.Name == "Cave")};

            List<Appointment> appointmentList = new List<Appointment>()

            {
                appointment1, appointment2, appointment3, appointment4
            };

            return appointmentList;
        }

        // Instantiate Clients
        public static List<Client> InstantiateClients()
        {
            Client client1 = new Client(89, "Louise", "Anna", "Peterson", DateTime.ParseExact("18-09-1989", "dd-MM-yyyy", null), ECaseType.Corporate, "Pacific Beach", 11, 1310, "Gotham Village");
            Client client2 = new Client(99, "Nathan", "Harry", "Gill", DateTime.ParseExact("04-12-1999", "dd-MM-yyyy", null), ECaseType.Family, "Rodeo Drive", 33, 1145, "Greenwhich Village");
            Client client3 = new Client(78, "Kent", "Bill", "Clark", DateTime.ParseExact("23-03-1978", "dd-MM-yyyy", null), ECaseType.Criminal, "Louisville Street", 55, 3500, "Grand Village");
            Client client4 = new Client(79, "Angela", "Hanna", "Jensen", DateTime.ParseExact("15-10-1978", "dd-MM-yyyy", null), ECaseType.Corporate, "Sunshine Street", 77, 2000, "Gotham Village");
            Client client5 = new Client(88, "Ali", "Jr.", "Mohammed", DateTime.ParseExact("09-02-1988", "dd-MM-yyyy", null), ECaseType.Family, "Houston Street", 74, 7200, "Greenwhich Village");
            Client client6 = new Client(69, "Sara", "Alice", "Trump", DateTime.ParseExact("23-05-1969", "dd-MM-yyyy", null), ECaseType.Criminal, "Broadway Street", 118, 9000, "Grand Village");
            Client client7 = new Client(87, "Kamala", "Ida", "Harris", DateTime.ParseExact("08-12-1979", "dd-MM-yyyy", null), ECaseType.Corporate, "Whitehouse Street", 88, 5000, "Gotham Village");
            Client client8 = new Client(43, "Luke", "Sean", "Norris", DateTime.ParseExact("11-09-1943", "dd-MM-yyyy", null), ECaseType.Family, "Roseville Street", 2, 7000, "Greenwhich Village");
            Client client9 = new Client(98, "Casper", "Henrik", "Davis", DateTime.ParseExact("16-06-1998", "dd-MM-yyyy", null), ECaseType.Criminal, "Longville Street", 66, 3000, "Grand Village");
            Client client10 = new Client(80, "Hilary", "Shay", "Clinton", DateTime.ParseExact("07-09-1980", "dd-MM-yyyy", null), ECaseType.Corporate, "New York", 111, 8000, "Gotham Village");

            List<Client> clientList = new List<Client>()
                {
                    client1, client2, client3, client4, client5, client6, client7, client8, client9, client10,
                };

            return clientList;
        }

        // Instantiate Cases
        public static List<Case> InstantiateCases()

        {
            Case case1 = new Case(1, 1001, ECaseType.Criminal, DateTime.ParseExact("25-06-2010", "dd-MM-yyyy", null), 400000, 1, "", "");
            Case case2 = new Case(2, 1002, ECaseType.Family, DateTime.ParseExact("13-08-2010", "dd-MM-yyyy", null), 250000, 2, "", "");
            Case case3 = new Case(3, 1003, ECaseType.Corporate, DateTime.ParseExact("07-09-2010", "dd-MM-yyyy", null), 500000, 1, "", "");
            Case case4 = new Case(4, 1004, ECaseType.Corporate, DateTime.ParseExact("19-11-2010", "dd-MM-yyyy", null), 800000, 4, "", "");
            Case case5 = new Case(5, 1005, ECaseType.Family, DateTime.ParseExact("22-02-2011", "dd-MM-yyyy", null), 1000000, 5, "", "");
            Case case6 = new Case(6, 1006, ECaseType.Criminal, DateTime.ParseExact("20-05-2011", "dd-MM-yyyy", null), 1200000, 6, "", "");
            Case case7 = new Case(7, 1007, ECaseType.Family, DateTime.ParseExact("10-09-2011", "dd-MM-yyyy", null), 300000, 7, "", "");
            Case case8 = new Case(8, 1008, ECaseType.Corporate, DateTime.ParseExact("31-01-2012", "dd-MM-yyyy", null), 1000000, 8, "", "");
            Case case9 = new Case(9, 1009, ECaseType.Corporate, DateTime.ParseExact("21-11-2012", "dd-MM-yyyy", null), 800000, 9, "", "");
            Case case10 = new Case(10, 1010, ECaseType.Family, DateTime.ParseExact("24-08-2012", "dd-MM-yyyy", null), 250000, 10, "", "");

            List<Case> cases = new List<Case>

            {
                case1, case2, case3, case4, case5, case6, case7, case8, case9, case10,
            };

            return cases;
        }
    }
}