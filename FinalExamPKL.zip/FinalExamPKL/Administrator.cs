﻿using System;
using System.Collections.Generic;
using System.Text;


namespace FinalExam

{
    public class Administrator : Employee, IListCases

    {
        public Administrator(int id, string password, string firstName, string lastName, DateTime joinedOn, string role)
            : base(id, password, firstName, lastName, joinedOn)

         // Role is specific to Administrator 
        {
            Role = role;
        }

        // Constructor that allows to instantiate an Administrator without providing all the values
        public Administrator()
        {
        }


        private string Role { get; set; }


        // Function looks through each of the Cases and writes the case down

        public void ListCases(List<Case> cases) 
        {
            List<Case> caseList = cases;
           
            Console.WriteLine("*** Cases *** \n");
            foreach (Case c in caseList)
            {
                Console.WriteLine(c);
            }

            Console.WriteLine("\nHit enter.");
            Console.ReadLine();
            
        }
    }
}
