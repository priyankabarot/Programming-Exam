﻿using System;
using System.Collections.Generic;
using System.Text;


namespace FinalExam

{
    // Interface - can be seen as a contract that ListCases needs to be implemented 

    public interface IListCases

    {
        void ListCases(List<Case> cases);
    }

}
