﻿using System;
using System.Collections.Generic;
using System.Text;


namespace FinalExam

{

    // Meeting Room is an entity by itself + has Capacity and Name

    public class MeetingRoom

    {
        public MeetingRoom(string name, int capacity)

        {
            Name = name;
            Capacity = capacity;
        }

        public string Name { get; set; }

        public int Capacity { get; set; }


        //Every class has a ToString method, but we override it to implement it in the specific way we need it

        public override string ToString()
        {
            return "Room name: " + Name +
                "\nRoom capacity: " + Capacity;
        }
    }
}
